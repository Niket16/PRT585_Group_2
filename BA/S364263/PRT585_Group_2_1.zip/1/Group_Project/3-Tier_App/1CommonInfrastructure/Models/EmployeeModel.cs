﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace _1CommonInfrastructure.Models
{
    public class EmployeeModel
    {

        public int EmployeeId { get; set; } // int
        public string EmployeeName { get; set; } // nvarchar(400)

    }

}
