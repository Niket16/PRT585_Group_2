namespace WebApplication3tierApp
{
    public class KaiInterface
    {
        public DateTime Date { get; set; }

        public string? Data { get; set; }
    }
}
