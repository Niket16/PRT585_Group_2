import React from 'react'

const Success = () => {
  return (
    <div>
      
    </div>
  )
}

export default Success
