import React from 'react'

const category = () => {
  return (
    <div>
      
    </div>
  )
}

export default category