import React from 'react'

const Cancel = () => {
  return (
    <div>
      
    </div>
  )
}

export default Cancel
