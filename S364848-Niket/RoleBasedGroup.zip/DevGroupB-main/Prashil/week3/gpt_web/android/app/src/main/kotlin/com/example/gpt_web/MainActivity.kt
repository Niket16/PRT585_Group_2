package com.example.gpt_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
