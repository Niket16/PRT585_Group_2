package com.example.todo_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
