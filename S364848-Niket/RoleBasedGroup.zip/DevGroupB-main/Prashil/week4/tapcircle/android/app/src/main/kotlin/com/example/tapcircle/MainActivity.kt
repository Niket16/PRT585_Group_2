package com.example.tapcircle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
