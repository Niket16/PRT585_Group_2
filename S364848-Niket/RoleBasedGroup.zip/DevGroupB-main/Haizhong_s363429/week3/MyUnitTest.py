import unittest

class TestApi(unittest.TestCase):
    def test_1(self):
        print("Hello world")
    
    def test_2(self):
        print("HAPPY TIME")

if __name__ == '__main__':
    unittest.main()
