import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h1 className='text-danger my-5'>404! <br /> Not found.</h1>
        </div>
    );
};

export default NotFound;