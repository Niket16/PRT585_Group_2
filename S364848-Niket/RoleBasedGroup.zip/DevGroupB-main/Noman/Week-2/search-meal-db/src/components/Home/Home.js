import React from 'react';
import './Home.css';
const Home = () => {
    return (
        <div className='home'>
            <h1>Welcome to MealDB</h1>
            <p>Here you can find your favourite dish</p>
        </div>
    );
};

export default Home;