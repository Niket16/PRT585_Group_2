# Dream Photography

## Live-site
 [dream-photography.web.app](https://dream-photography.web.app/)
 
 ### Details About Dream Photography
 * Dream Photography provides you different types of packages
 * You can booked any packages only when you are logged in
 * Differnces between Authorization and Authentication are discussed here
 * Details about Firebase authentication are also given here
 * Login and Register are applied here by using Firebase authentication

 #
 ### Technology used:
 - React Library
 - React Router
 - Bootstrap 5
 - Firebase Authentication
 - React Tostify
