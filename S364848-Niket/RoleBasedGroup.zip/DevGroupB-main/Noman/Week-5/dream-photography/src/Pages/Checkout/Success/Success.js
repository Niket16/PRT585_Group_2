import React from 'react';

const Success = () => {
    return (
        <div>
            <h1 className="text-center my-3">Thank you for your trust!</h1>
        </div>
    );
};

export default Success;