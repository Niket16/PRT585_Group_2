import React from 'react';

const Footer = () => {
    return (
        <div className='text-center p-3 bg-dark text-white mt-auto'>
            <p>Copyright &copy; Abdullah Al Noman, 2022</p>
        </div>
    );
};

export default Footer;