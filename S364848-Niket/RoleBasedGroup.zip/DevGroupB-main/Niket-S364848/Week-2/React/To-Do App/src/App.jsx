import ToDoList from "./ToDoList"

function App() {
  return(<div>
    <ToDoList />
  </div>);
}

export default App
