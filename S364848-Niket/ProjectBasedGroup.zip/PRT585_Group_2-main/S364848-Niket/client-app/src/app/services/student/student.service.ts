/**
 */

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable(
  // {
  // providedIn: 'root'
// }
)
 export class StudentService {

  //  constructor() { }

   // Get all students list via API or any data storage
  //  getAllStudents(){
  //    let studentList:any;
  //    if(localStorage.getItem('students') && localStorage.getItem('students') != '') {
  //      studentList = {
  //        code : 200,
  //        message : "Students List Fetched Successfully",
  //        data : JSON.parse(localStorage.getItem('students') || '')
  //      }
  //    }else{
  //      studentList = {
  //        code : 200,
  //        message : "Students List Fetched Successfully",
  //        data : JSON.parse(localStorage.getItem('students') || '')
  //      }
  //    }
  //    return studentList;
  //  }

  //  doRegisterStudent(data: any, index: number){
  //    let studentList = JSON.parse(localStorage.getItem('students') || '');
  //    let returnData;
  //    if(index != null) {
  //      for (var i = 0; i < studentList.length; i++) {
  //        if (index != i && studentList[i].email == data.email) {
  //          returnData = {
  //            code : 503,
  //            message : "Email Address Already In Use",
  //            data : null
  //          }
  //          return returnData;
  //        }
  //      }

  //      studentList[index] = data;
  //      localStorage.setItem('students',JSON.stringify(studentList));
  //      returnData = {
  //        code : 200,
  //        message : "Student Successfully Updated",
  //        data : JSON.parse(localStorage.getItem('students') || '')
  //      }
  //    }else{
  //      data.id = this.generateRandomID();
  //      for (var i = 0; i < studentList.length; i++) {
  //        if (studentList[i].email == data.email) {
  //          returnData = {
  //            code : 503,
  //            message : "Email Address Already In Use",
  //            data : null
  //          }
  //          return returnData;
  //        }
  //      }
  //      studentList.unshift(data);

  //      localStorage.setItem('students',JSON.stringify(studentList));

  //      returnData = {
  //        code : 200,
  //        message : "Student Successfully Added",
  //        data : JSON.parse(localStorage.getItem('students') || '')
  //      }
  //    }
  //    return returnData;
  //  }

  //  deleteStudent(index:number){
  //    let studentList = JSON.parse(localStorage.getItem('students') || '');

  //    studentList.splice(index, 1);

  //    localStorage.setItem('students',JSON.stringify(studentList));

  //    let returnData = {
  //      code : 200,
  //      message : "Student Successfully Deleted",
  //      data : JSON.parse(localStorage.getItem('students') || '')
  //    }

  //    return returnData;
  //  }



  //  getStudentDetails(index:number){
  //    let studentList = JSON.parse(localStorage.getItem('students') || '');

  //    let returnData = {
  //      code : 200,
  //      message : "Student Details Fetched",
  //      studentData : studentList[index]
  //    }

  //    return returnData;
  //  }


  //  generateRandomID() {
  //    var x = Math.floor((Math.random() * Math.random() * 9999));
  //    return x;
  //  }

  private apiUrl = 'https://localhost:7246/api/Student';

  constructor(private http: HttpClient) { }

  getAllStudents(): Observable<any> {
    return this.http.get(this.apiUrl, { withCredentials: true });
  }

  getStudentById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`, { withCredentials: true });
  }

  getStudentByCode(code: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/code/${code}`, { withCredentials: true });
  }

  createStudent(Student: any): Observable<any> {
    return this.http.post(this.apiUrl, Student, { withCredentials: true });
  }

  updateStudent(Student: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/update`, Student, { withCredentials: true });
  }

  deleteStudent(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`, { withCredentials: true });
  }

 }
/**
 */
